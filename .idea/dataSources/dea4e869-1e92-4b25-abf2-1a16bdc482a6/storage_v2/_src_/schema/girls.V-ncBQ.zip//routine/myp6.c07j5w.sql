create
    definer = root@localhost procedure myp6(INOUT a int, INOUT b int)
begin
    select 2*a into a;
    set b= b*2;

end;

