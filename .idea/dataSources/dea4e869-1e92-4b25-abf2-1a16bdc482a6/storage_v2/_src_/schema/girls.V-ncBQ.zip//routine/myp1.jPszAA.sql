create
    definer = root@localhost procedure myp1()
begin
    insert into admin(username,password) values('john1','000'),('lily','15646'),('jack','1646');
end;

