create
    definer = root@localhost procedure myp5(IN beautyName varchar(20), OUT boyName varchar(20), OUT userCP int)
begin
    select bo.boyname,bo.userCP into boyName,userCP from boys bo inner join beauty b on b.id=bo.id
    where b.name = beautyName;
end;

